import ast
from pathlib import Path


SOURCE = Path("main.py")
OUTPUT = Path("web_main.py")

SOUND_NAMES = {
    "flap_sound",
    "gem_sound",
    "hit_sound",
    "fireball_sound",
    "boss_hit_sound",
    "warning_sound",
    "victory_sound",
    "level_sound",
}


class WebConverter(ast.NodeTransformer):

    def __init__(self):
        self.game_loop_found = False
        self.loop_globals = set()

    def visit_Import(self, node):
        # Remove desktop WAV-generation imports.
        kept = [
            alias
            for alias in node.names
            if alias.name not in {"io", "wave", "struct"}
        ]

        if not kept:
            return None

        return ast.Import(names=kept)

    def visit_ImportFrom(self, node):
        if node.module in {"io", "wave", "struct"}:
            return None

        return node

    def visit_FunctionDef(self, node):

        # Browser-safe sound generator.
        if node.name == "create_tone":
            return ast.parse(
                """
def create_tone(*args, **kwargs):
    return None
"""
            ).body[0]

        # Safe sound player.
        if node.name == "play_sound":
            return ast.parse(
                """
def play_sound(sound):
    if SOUND_ENABLED and sound is not None:
        try:
            sound.play()
        except pygame.error:
            pass
"""
            ).body[0]

        return self.generic_visit(node)

    def visit_Assign(self, node):

        # Replace generated sound assignments with None.
        for target in node.targets:
            if isinstance(target, ast.Name):
                if target.id in SOUND_NAMES:
                    return ast.Assign(
                        targets=node.targets,
                        value=ast.Constant(value=None),
                    )

        return self.generic_visit(node)

    def visit_While(self, node):

        # Find the ACTUAL:
        #
        # while running:
        #
        if (
            not self.game_loop_found
            and isinstance(node.test, ast.Name)
            and node.test.id == "running"
        ):

            self.game_loop_found = True

            # Transform contents.
            node = self.generic_visit(node)

            # Collect variables assigned inside the game loop.
            assigned_names = set()

            class AssignmentCollector(ast.NodeVisitor):

                def visit_Name(self, n):
                    if isinstance(n.ctx, ast.Store):
                        assigned_names.add(n.id)

            AssignmentCollector().visit(node)

            # Save them for the async main function.
            self.loop_globals = assigned_names

            # IMPORTANT:
            # Do NOT put "global" inside the while loop.
            # The global statement will be placed at the TOP
            # of async main(), before "while running:".

            # Add browser yield after clock.tick(FPS).
            new_body = []
            await_added = False

            for statement in node.body:

                new_body.append(statement)

                if self.is_clock_tick(statement):

                    new_body.append(
                        ast.Expr(
                            value=ast.Await(
                                value=ast.Call(
                                    func=ast.Attribute(
                                        value=ast.Name(
                                            id="asyncio",
                                            ctx=ast.Load(),
                                        ),
                                        attr="sleep",
                                        ctx=ast.Load(),
                                    ),
                                    args=[
                                        ast.Constant(value=0)
                                    ],
                                    keywords=[],
                                )
                            )
                        )
                    )

                    await_added = True

            if not await_added:

                new_body.append(
                    ast.Expr(
                        value=ast.Await(
                            value=ast.Call(
                                func=ast.Attribute(
                                    value=ast.Name(
                                        id="asyncio",
                                        ctx=ast.Load(),
                                    ),
                                    attr="sleep",
                                    ctx=ast.Load(),
                                ),
                                args=[
                                    ast.Constant(value=0)
                                ],
                                keywords=[],
                            )
                        )
                    )
                )

            node.body = new_body

            return node

        return self.generic_visit(node)

    @staticmethod
    def is_clock_tick(statement):

        if not isinstance(statement, ast.Expr):
            return False

        call = statement.value

        if not isinstance(call, ast.Call):
            return False

        func = call.func

        if not isinstance(func, ast.Attribute):
            return False

        if func.attr != "tick":
            return False

        if not isinstance(func.value, ast.Name):
            return False

        return func.value.id == "clock"


def make_global_statement(names):

    # running must definitely be global.
    names = set(names)
    names.add("running")

    return ast.Global(
        names=sorted(names)
    )


def main():

    if not SOURCE.exists():

        print("ERROR: main.py was not found.")
        print()
        print("Make sure these files are together:")
        print("  main.py")
        print("  make_web.py")
        return

    print("Reading original main.py...")

    source_text = SOURCE.read_text(
        encoding="utf-8"
    )

    print("Parsing original game...")

    try:

        tree = ast.parse(
            source_text,
            filename="main.py"
        )

    except SyntaxError as e:

        print("ERROR: main.py has a syntax error.")
        print(e)
        return

    converter = WebConverter()

    tree = converter.visit(tree)

    if not converter.game_loop_found:

        print()
        print("ERROR: Could not find:")
        print("    while running:")
        print()
        print("The original main.py was NOT changed.")
        return

    # ---------------------------------------------------------
    # Add asyncio + sys imports.
    # ---------------------------------------------------------

    asyncio_import = ast.Import(
        names=[
            ast.alias(
                name="asyncio",
                asname=None
            )
        ]
    )

    sys_import = ast.Import(
        names=[
            ast.alias(
                name="sys",
                asname=None
            )
        ]
    )

    tree.body.insert(
        0,
        sys_import
    )

    tree.body.insert(
        0,
        asyncio_import
    )

    # ---------------------------------------------------------
    # Find actual while running loop.
    # ---------------------------------------------------------

    loop_index = None
    loop_node = None

    for index, statement in enumerate(tree.body):

        if (
            isinstance(statement, ast.While)
            and isinstance(statement.test, ast.Name)
            and statement.test.id == "running"
        ):

            loop_index = index
            loop_node = statement
            break

    if loop_node is None:

        print(
            "ERROR: Game loop could not be located."
        )

        return

    # ---------------------------------------------------------
    # Find:
    #
    # running = True
    #
    # immediately before while running:
    # ---------------------------------------------------------

    running_assign = None

    if loop_index > 0:

        previous = tree.body[
            loop_index - 1
        ]

        if (
            isinstance(previous, ast.Assign)
            and any(
                isinstance(target, ast.Name)
                and target.id == "running"
                for target in previous.targets
            )
        ):

            running_assign = previous

            before_loop = tree.body[
                :loop_index - 1
            ]

        else:

            before_loop = tree.body[
                :loop_index
            ]

    else:

        before_loop = []

    if running_assign is None:

        running_assign = ast.Assign(
            targets=[
                ast.Name(
                    id="running",
                    ctx=ast.Store()
                )
            ],
            value=ast.Constant(
                value=True
            )
        )

    # ---------------------------------------------------------
    # GLOBAL STATEMENT
    #
    # This is the important fix.
    #
    # It goes BEFORE:
    #
    # running = True
    # while running:
    # ---------------------------------------------------------

    global_statement = make_global_statement(
        converter.loop_globals
    )

    # ---------------------------------------------------------
    # Browser-safe sound flag.
    # ---------------------------------------------------------

    sound_enabled = ast.Assign(
        targets=[
            ast.Name(
                id="SOUND_ENABLED",
                ctx=ast.Store()
            )
        ],
        value=ast.Compare(
            left=ast.Attribute(
                value=ast.Name(
                    id="sys",
                    ctx=ast.Load()
                ),
                attr="platform",
                ctx=ast.Load()
            ),
            ops=[
                ast.NotEq()
            ],
            comparators=[
                ast.Constant(
                    value="emscripten"
                )
            ]
        )
    )

    # ---------------------------------------------------------
    # Async main.
    # ---------------------------------------------------------

    async_main = ast.AsyncFunctionDef(

        name="main",

        args=ast.arguments(
            posonlyargs=[],
            args=[],
            kwonlyargs=[],
            kw_defaults=[],
            defaults=[],
        ),

        body=[
            # GLOBAL MUST COME FIRST.
            global_statement,

            # Then running = True.
            running_assign,

            # Then while running.
            loop_node,

            # Quit after loop.
            ast.Expr(
                value=ast.Call(
                    func=ast.Attribute(
                        value=ast.Name(
                            id="pygame",
                            ctx=ast.Load()
                        ),
                        attr="quit",
                        ctx=ast.Load()
                    ),
                    args=[],
                    keywords=[]
                )
            ),
        ],

        decorator_list=[],
        returns=None,
        type_comment=None,
    )

    # ---------------------------------------------------------
    # asyncio.run(main())
    # ---------------------------------------------------------

    run_main = ast.If(

        test=ast.Compare(

            left=ast.Name(
                id="__name__",
                ctx=ast.Load()
            ),

            ops=[
                ast.Eq()
            ],

            comparators=[
                ast.Constant(
                    value="__main__"
                )
            ],
        ),

        body=[
            ast.Expr(
                value=ast.Call(

                    func=ast.Attribute(
                        value=ast.Name(
                            id="asyncio",
                            ctx=ast.Load()
                        ),
                        attr="run",
                        ctx=ast.Load()
                    ),

                    args=[
                        ast.Call(
                            func=ast.Name(
                                id="main",
                                ctx=ast.Load()
                            ),
                            args=[],
                            keywords=[]
                        )
                    ],

                    keywords=[]
                )
            )
        ],

        orelse=[]
    )

    # ---------------------------------------------------------
    # Put SOUND_ENABLED after imports.
    # ---------------------------------------------------------

    final_body = list(
        before_loop
    )

    insert_index = 0

    while (
        insert_index < len(final_body)
        and isinstance(
            final_body[insert_index],
            (
                ast.Import,
                ast.ImportFrom
            )
        )
    ):

        insert_index += 1

    final_body.insert(
        insert_index,
        sound_enabled
    )

    # Add async main.
    final_body.append(
        async_main
    )

    # Add asyncio.run(main()).
    final_body.append(
        run_main
    )

    tree.body = final_body

    ast.fix_missing_locations(tree)

    # ---------------------------------------------------------
    # Generate web_main.py
    # ---------------------------------------------------------

    print("Generating web_main.py...")

    try:

        generated = ast.unparse(
            tree
        )

    except Exception as e:

        print(
            "ERROR while generating web_main.py:"
        )
        print(e)
        return

    # ---------------------------------------------------------
    # Validate generated Python.
    # ---------------------------------------------------------

    print("Checking generated file...")

    try:

        ast.parse(
            generated,
            filename="web_main.py"
        )

    except SyntaxError as e:

        print()
        print(
            "ERROR: Generated web_main.py is invalid."
        )
        print(e)
        return

    OUTPUT.write_text(
        generated + "\n",
        encoding="utf-8"
    )

    print()
    print("=" * 60)
    print("SUCCESS!")
    print("=" * 60)
    print()
    print("Created:")
    print("    web_main.py")
    print()
    print("Original main.py was NOT changed.")
    print()
    print("Now run:")
    print("    python web_main.py")
    print()


if __name__ == "__main__":
    main()